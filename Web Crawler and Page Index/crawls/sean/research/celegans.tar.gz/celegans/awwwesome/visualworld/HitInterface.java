package awwwesome.visualworld;

public abstract interface HitInterface
    {
    public abstract void doMouseEvent(int x, int y);
    }

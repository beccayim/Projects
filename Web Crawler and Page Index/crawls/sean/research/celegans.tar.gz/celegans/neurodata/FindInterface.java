package neurodata;

/** How a FindPanel responds to its creator. */

public interface FindInterface
    {
    public String doFind(String find_this); // return true if successfully found
    }

package neurodata;


/** HighlightInterface is how a the Highlight object responds to its creator. */

public interface HighlightInterface
    {
    public void setDisplayInfo(String result,int highlight_option,boolean display_others,boolean display_label, boolean display_zcells);
    }

package neurodata;

import java.awt.Color;

/** A singleton object containing predefined colors for the Canvas3D drawer. You can
 change these to adjust the color effect as you like.  If you want to change the
 Java3D/OpenGL colors, you should instead modify GLCellPoint.java.  */

public class Colors extends Object
    {
	public static Color backgroundColor = Color.black;
	public static Color coordinatesColor = Color.green;
	public static Color cellColor = Color.blue;
	public static Color alternateCellColor = Color.red;
	public static Color labelColor = Color.white;
	public static Color selectedCellColor = Color.white;
	public static Color synapseOutColor = Color.darkGray;
	public static Color synapseInColor = Color.lightGray;
	public static Color gapJunctionColor = Color.lightGray;

    }

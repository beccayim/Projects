package neurodata;


/** How a DialogBox responds to its creator. */

public interface DialogBoxResponse
    {
    public void dialogResult(DialogBox sender, int result);
    }

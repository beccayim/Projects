package neurodata;

import java.util.Vector;
import java.lang.System;


/* An expression pattern.  Expression patterns have a name and a list of cells belonging to that particular pattern. */

public class ExpressionPattern extends Object
    {
    public String name;
    public Vector cells;
    
    public ExpressionPattern()
	{
	cells = new Vector();
	}

    }

package neurodata;


/** Used by the Sorter to respond to its creator.  Its creator must implement
  this single method, which indicates which of two objects is "greater". */

public interface SortInterface
    {
    public boolean greaterThan(Object o1, Object o2);
    }

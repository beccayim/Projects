package neurodata;
import java.util.Vector;



/** Sorter implements QuickSort.  Actually, there are serious bugs in this implementation,
so you've been warned.  But it works just great for sorting the list of cell names in the
Find Cell panel. */

public class Sorter extends Vector
    {
    public void sort(SortInterface withThisSortInterface)
	{
        sortRange(0, size()-1, 0, withThisSortInterface);
	}

    void sortRange(int start, int end, int depth, SortInterface si) 
	{
	int high, low;
	
	if (start >= end) return;
	
        int middle = (start + end)/2;
	Object pivot=elementAt(middle);
	
        low = start;
        high= end;
	
        while(low <= high)
	    {
	    while(low <= high && !(si.greaterThan(elementAt(low),pivot)))
		++low;
	    
	    while(low <= high && si.greaterThan(elementAt(high),pivot))
		--high;
	    
	    if (low <= high) 
		{
		Object o = elementAt(high);
		setElementAt(elementAt(low), high);
		setElementAt(o, low);
		}
	    }
	
        if (low > end) 
	    {
            Object o = elementAt(high);
            setElementAt(elementAt(middle), high);
            setElementAt(o, middle);
	    
            sortRange(start, end-1, depth+1, si);
	    }
	else 
	    {
            sortRange(start, high, depth+1, si);
            sortRange(low, end, depth+1, si);
	    }
	}
    }

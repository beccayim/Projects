package neurodata.GL;

public class GLCellPoint
    {
    public void setColor(java.awt.Color c)
	{
	}
    }

package neurodata.GL;

import java.awt.*;

public class GLDisplay extends Component
    {
    public static boolean supportingGL = false;   // this is just a stub
    public GLDisplay() { super(); }
    public void formScene(int timestamp, neurodata.Cells cells, neurodata.Cubes cubes) { }
    public static GLDisplay newGLDisplay() { return new GLDisplay(); }
    }

    

package neurodata;

import java.util.Vector;
import java.lang.System;


/** A single Cell Group, with a name and a list of cells belonging to the group. */

public class CellGroup extends Object
    {
    public String name;
    public Vector cells;
    
    public CellGroup()
	{
	cells = new Vector();
	}

    }

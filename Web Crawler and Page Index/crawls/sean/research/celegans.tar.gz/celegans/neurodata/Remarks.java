package neurodata;
import java.awt.*;
import java.lang.*;
import java.util.*;

/**  Remarks displays a Cell's remarks in a special window.  Unfortunately, the AWT really stinks,
  and it's not easy to display remarks on more than one line.  :-(  
*/

public class Remarks extends Frame
    {
    TextArea remarks;

    public Remarks()
	{
	remarks = new TextArea();
	remarks.setEditable(false);
	setLayout(new BorderLayout());
	setTitle("Remarks");
	add("Center",remarks);
	pack();
	resize(500,100);
	}

    public void setRemarks(String r)
	{
	remarks.setText(r);
	}

    public boolean handleEvent(Event evt)
	{
	if (evt.id==Event.WINDOW_DESTROY)
	    {
	    hide();		// DON'T destroy; it's expensive to recreate me!
	    return true;
	    }
	else return super.handleEvent(evt);
	}
    }

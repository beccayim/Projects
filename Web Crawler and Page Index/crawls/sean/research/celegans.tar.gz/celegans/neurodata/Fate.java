package neurodata;

import java.util.Vector;
import java.lang.System;

/* A Cell Fate.  Cell Fates have a name and a list of cells belonging to that particular cell fate. */

public class Fate extends Object
    {
    public String name;
    public Vector cells;
    
    public Fate()
	{
	cells = new Vector();
	}

    }

package neurodata.GL;

import com.sun.j3d.utils.geometry.Sphere;
import javax.media.j3d.*;

/** PickSphere is a sphere displayed in the GLDisplay display, which can be picked (all of them can).  Picking it will cause its respective Cell to be selected. */

public class PickSphere extends Sphere
{
public GLCellPoint glcellpoint;
public PickSphere(float radius,
              int primflags,
              int divisions,
              javax.media.j3d.Appearance ap,
	      GLCellPoint cp)
    {
	super(radius,primflags,divisions,ap); glcellpoint=cp;
    }
public void select()
	{
	glcellpoint.selector.select(glcellpoint.cellpoint);
	}

}

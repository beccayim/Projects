package neurodata;

/** How a DisplaySynapses object responds to its creator. */

public interface DisplaySynapseInterface
    {
    public void setSynapseInfo(int synapse_option, boolean display_label);
    }

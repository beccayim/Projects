/*
	Copyright (C) 1994 Sean Luke

	COWSIBRadio.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibrary.h"

@interface COWSIBRadio:COWSLibrary <InterpreterToLibrary>
{
	COWSArgumentList*	connectors;
	int					inited;
}

- awake;
- init;
- free;

- add:sender;				// adds sender to list of connectors to load

@end

COWSIBRadio* COWS_RADIO;
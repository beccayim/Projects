// Formalities
	//	Copyright (C) 1994 Guus C. Bloemsma
	//
	//	COWSMathLibrary.h
	//	Version 1.0			Guus C. Bloemsma

#import "COWSLibrary.h"

@interface COWSMathLibrary:COWSLibrary <InterpreterToLibrary> {
	}

// no need to export any functions

@end
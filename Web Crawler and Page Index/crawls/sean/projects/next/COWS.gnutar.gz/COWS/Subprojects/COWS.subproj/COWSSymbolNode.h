/*
	Copyright (C) 1994 Sean Luke

	COWSSymbolNode.h
	Version 1.0
	Sean Luke
	
*/

#define COWSSTARTSET	1
#define COWSDONESET		2
#define COWSSTARTIF		3
#define COWSSTARTTHEN	4
#define COWSSTARTELSE	5
#define COWSDONEIF		6
#define COWSSTARTWHILE	7
#define COWSTRUEWHILE	8
#define COWSFALSEWHILE	9
#define COWSDONEWHILE	10
#define COWSSTARTFOR	11
#define COWSENDFOR		12
#define COWSSTEPFOR		13
#define COWSDOFOR		14
#define COWSFALSEFOR	15
//#define COWSTRUEFOR		16
#define COWSTESTFOR		17
#define COWSCONTINUEFOR	18

#import "COWSStringNode.h"

@interface COWSSymbolNode:COWSStringNode
{
	int state;					// for use by for, while, set, and if
	int pos;					// for use by for and while
	COWSStringNode* variable;	// for use by for and set
	float start;				// for use by for
	float end;					// for use by for
	float step;					// for use by for
}

- init;
- setState:(int)this_state;
- (int) state;
- (COWSStringNode*) variable;
- free;
- setPos:(int)this_pos;
- (int) pos;
- setStart:(float)this_start;
- (float) start;
- setEnd:(float) this_end;
- (float) end;
- setStep:(float) this_step;
- (float) step;

@end
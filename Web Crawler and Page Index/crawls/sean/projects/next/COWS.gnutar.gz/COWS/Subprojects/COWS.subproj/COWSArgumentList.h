/*
	Copyright (C) 1994 Sean Luke

	COWSArgumentList.h
	Version 1.0
	Sean Luke
	
*/



#import <objc/Object.h>
#import "COWSStringNode.h"
#import "COWSStack.h"

@interface COWSArgumentList:COWSStack
{
	id temp;
}

- init;
- first;		// O(1)
- last;			// O(n)
- next;			// if you call pop, 
				// don't call next until you've called first or last!
- prev;			// likewise.
- now;			// likewise.  Now gives the current pointed object without
				// moving to the next one.  It returns NULL if nothing. 
- copy;
@end

/*
	Copyright (C) 1994 Sean Luke

	COWSControlPanel.m
	Version 1.4
	Sean Luke
	
	An Easy-To-Hook-Up control panel
	Designed to work with the COWSUserController
		
*/

#import "COWSControlPanel.h"

@implementation COWSControlPanel

- connect:sender
	{
	[loadButton setTarget:sender];
	[loadButton setAction:@selector(load:)];
	[loadAndRunButton setTarget:sender];
	[loadAndRunButton setAction:@selector(loadAndRunOrStop:)];
	[runButton setTarget:sender];
	[runButton setAction:@selector(run:)];
	[lockedButton setTarget:sender];
	[lockedButton setAction:@selector(setLockedToMe:)];
	[foregroundButton setTarget:sender];
	[foregroundButton setAction:@selector(setForegroundToMe:)];
	return self;
	}
	
- loadAndRunButton
	{
	return loadAndRunButton;
	}
	
- loadButton
	{
	return loadButton;
	}
	

- runButton
	{
	return runButton;
	}
	

- lockedButton
	{
	return lockedButton;
	}
	

- foregroundButton
	{
	return foregroundButton;
	}
	

- function
	{
	return function;
	}
	

- arg1
	{
	return arg1;
	}
	

- arg2
	{
	return arg2;
	}
	

- arg3
	{
	return arg3;
	}
	

- arg4
	{
	return arg4;
	}
	


@end
/*
	Copyright (C) 1994 Sean Luke

	COWSLibraryFunctionNode.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibraryFunctionNode.h"


@implementation COWSLibraryFunctionNode


- setSelector:(SEL) this_selector
	{
	selector=this_selector;
	return self;
	}
	

- (SEL) selector
	{
	return selector;
	}
	
- printContents
	{
	return self;
	}
		
@end
/*
	Copyright (C) 1994 Sean Luke

	COWSSymbolNode.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSSymbolNode.h"
#import <stdlib.h>
#import <stdio.h>

@implementation COWSSymbolNode

- init
	{
	id returnval=[super init];
	state=0;
	pos=0;
	start=0;
	end=0;
	step=0;
	variable=[[COWSStringNode alloc] init];
	return returnval;
	}
	
	

- setState:(int)this_state
	{
	state=this_state;
	return self;
	}
	
	

- (int) state
	{
	return state;
	}
	
	

- (COWSStringNode*) variable
	{
	return variable;
	}
	
	

- free
	{
	[variable free];
	return [super free];
	}
	
	

- setPos:(int)this_pos
	{
	pos=this_pos;
	return self;
	}
	
	

- (int) pos
	{
	return pos;
	}


- setStart:(float)this_start
	{
	start=this_start;
	return self;
	}
	
	

- (float) start
	{
	return start;
	}


- setEnd:(float)this_end
	{
	end=this_end;
	return self;
	}
	
	

- (float) end
	{
	return end;
	}


- setStep:(float)this_step
	{
	step=this_step;
	return self;
	}
	
	

- (float) step
	{
	return step;
	}


@end
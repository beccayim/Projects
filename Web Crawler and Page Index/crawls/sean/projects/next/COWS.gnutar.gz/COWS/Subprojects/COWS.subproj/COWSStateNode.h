/*
	Copyright (C) 1994 Sean Luke

	COWSStateNode.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSStringNode.h"
#import "COWSArgumentList.h"
#import <objc/HashTable.h>
#import <string.h>
#import <stdlib.h>
#import <stdio.h>

@interface COWSStateNode:COWSStringNode
{
	HashTable* 	dictionary;
	COWSArgumentList* arguments;
	int			pos;
}

- init;
- free;
- (COWSArgumentList*) arguments;
- setArguments:this;			// replaces arguments with new arguments
								// used exclusively by the copy method
- (HashTable*) dictionary;
- (int) pos;
- setPos:(int) this;
- printContents;				// printfs contents.  Debugging measure
- copy;							// used exclusively by the stack.
								// returns a duplicate copy of this node.

@end
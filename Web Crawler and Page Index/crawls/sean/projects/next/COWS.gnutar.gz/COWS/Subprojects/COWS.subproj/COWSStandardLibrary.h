/*
	Copyright (C) 1994 Sean Luke

	COWSStandardLibrary.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibrary.h"
#import "COWSInterpreter.h"
#import <string.h>
#import <stdio.h>
#import <time.h>
#import <stdlib.h>
#import <math.h>

@interface COWSStandardLibrary:COWSLibrary <InterpreterToLibrary>
{
}

- COWSfunc_do:arg_list;
- COWSfunc_dofirst:arg_list;
- COWSfunc_print:arg_list;
- COWSfunc_is:arg_list;
- COWSfunc_and:arg_list;
- COWSfunc_or:arg_list;
- COWSfunc_not:arg_list;
- COWSfunc_concatenate:arg_list;
- COWSfunc_quote:arg_list;
- COWSfunc_equal:arg_list;
- COWSfunc_greater:arg_list;
- COWSfunc_lesser:arg_list;
- COWSfunc_add:arg_list;
- COWSfunc_subtract:arg_list;
- COWSfunc_multiply:arg_list;
- COWSfunc_divide:arg_list;
- COWSfunc_error:arg_list;


@end
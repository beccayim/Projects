/*
	Copyright (C) 1994 Sean Luke

	COWSSystemLibrary.h
	Version 1.0
	Sean Luke
	
*/

// This library is far from finished--it has just enough functions to be
// dangerous!  Right now it's just got covers for a few NeXTSTEP and
// C functions.  But certainly more is to come.


#import "COWSLibrary.h"

@interface COWSSystemLibrary:COWSLibrary <InterpreterToLibrary>
{
	id	interpreter;
}

// functions
- beep:arg_list;
- userName:arg_list;
- ping:arg_list;
- alert:arg_list;				// up to 3 buttons

// defaults
- setDefault:arg_list;
- getDefault:arg_list;
- removeDefault:arg_list;

// application
- appName:arg_list;
- language:arg_list;			// systemLanguages

// time
- time:arg_list;

- sleep:arg_list;
- execute:arg_list;

@end
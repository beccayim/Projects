// Formalities
	//	Copyright (C) 1994 Guus C. Bloemsma
	//
	//	COWSMathLibrary.h
	//	Version 1.0			Guus C. Bloemsma
	
// Generated using Michal Jaegermann's Math Library generator.
// Broken up and tidied by Sean Luke


#import "COWSLibrary.h"

@interface COWSExtendedMathLibrary:COWSLibrary <InterpreterToLibrary> {
	}

// no need to export any functions

@end
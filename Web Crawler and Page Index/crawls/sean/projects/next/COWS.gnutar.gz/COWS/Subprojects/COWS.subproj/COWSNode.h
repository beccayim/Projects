/*
	Copyright (C) 1994 Sean Luke

	COWSNode.m
	Version 1.0
	Sean Luke
	
*/




#import <objc/Object.h>


@interface COWSNode:Object
{
	id	next;
	id	prev;
}

- init;
- setNext:this;
- next;
- setPrev:this;
- prev;
- free;
	
@end
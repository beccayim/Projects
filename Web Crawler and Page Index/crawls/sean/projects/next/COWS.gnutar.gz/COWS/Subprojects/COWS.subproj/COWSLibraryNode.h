/*
	Copyright (C) 1994 Sean Luke

	COWSLibraryNode.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSNode.h"

@interface COWSLibraryNode:COWSNode
{
	id		target;
}

- setTarget:this_target;
- target;

@end
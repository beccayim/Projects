/*
	Copyright (C) 1994 Sean Luke

	COWSArrayNode.h
	Version 1.0
	Sean Luke
	
*/




#import <objc/Object.h>
#import <stdlib.h>
#import "COWSStringNode.h"
#define COWSMAXARRAYLIMITS 256

@interface COWSArrayNode:Object
{
	int					size;			// greater than 0
	int					num_limits;		// greater than 0
	int					limits[COWSMAXARRAYLIMITS];
	COWSStringNode**	table;
}

- initTable:(const int*) these_limits:(int) this_num_limits;
- setValue:(const int*) coords:(COWSStringNode*) value;
- (COWSStringNode*) value:(const int*) coords;
- free;

@end
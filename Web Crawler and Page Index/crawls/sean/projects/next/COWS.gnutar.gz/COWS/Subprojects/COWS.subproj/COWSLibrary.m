/*
	Copyright (C) 1994 Sean Luke

	COWSLibrary.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibrary.h"

@implementation COWSLibrary


- loadLibrary:sender
	{
	return self;
	}

	
@end
/*
	Copyright (C) 1994 Sean Luke

	COWSLibrary.h
	Version 1.0
	Sean Luke
	
*/




#import <objc/Object.h>
#import "COWSProtocols.h"
#import "COWSInterpreter.h"
#import <appkit/NXImage.h>		// IB palette

@interface COWSLibrary:Object <InterpreterToLibrary>
{
}

// - loadLibrary:sender;		// this is defined in InterpreterToLibrary,
								// but exists here as a reminder to implement
								// it in your subclasses of COWSLibrary!!!
@end
/*
	Copyright (C) 1994 Sean Luke

	COWSLibraryNode.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibraryNode.h"


@implementation COWSLibraryNode

- setTarget:this_target
	{
	target=this_target;
	return self;
	}
	

- target
	{
	return target;
	}
	

@end
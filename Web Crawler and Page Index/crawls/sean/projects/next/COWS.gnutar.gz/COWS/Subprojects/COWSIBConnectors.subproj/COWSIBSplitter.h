/*
	Copyright (C) 1994 Sean Luke

	COWSIBSplitter.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibrary.h"
#import "COWSIBRadio.h"

extern COWSIBRadio* COWSRADIO;

@interface COWSIBSplitter:COWSLibrary <InterpreterToLibrary>
{
	id library1;
	id library2;
	id library3;
	id library4;
	id library5;
	id library6;
	id library7;
	id library8;
	int inited;
	BOOL use_radio;
}

- awake;
- init;
- read:(NXTypedStream*) stream;
- write:(NXTypedStream*) stream;

@end
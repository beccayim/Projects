/*
	Copyright (C) 1994 Sean Luke

	COWSStack.h
	Version 1.0
	Sean Luke
	
*/




#import <objc/Object.h>

@interface COWSStack:Object
{
	id current;
}

- init;
- push:this;
- pop;
- top;
- clear;
- (int) number;
- topSymbol;		// returns NULL if there is no symbol above a state
- topState;
- free;
- printContents;
	
@end
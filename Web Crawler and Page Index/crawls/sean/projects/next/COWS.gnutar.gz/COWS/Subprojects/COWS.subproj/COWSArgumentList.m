/*
	Copyright (C) 1994 Sean Luke

	COWSArgumentList.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSArgumentList.h"

@implementation COWSArgumentList

- init
	{
	id returnval=[super init];
	temp=NULL;
	return returnval;
	}
	
	
- first
	{
	temp=current;
	return temp;
	}
	
- next
	{
	if (temp==NULL) return temp;
	temp=[temp next];
	return temp;
	}

- now
	{
	return temp;
	}

- prev
	{
	if (temp==NULL) return temp;
	temp=[temp prev];
	return temp;
	}
	
- last
	{
	temp=current;
	if (temp==NULL) return temp;
	while ([temp next]!=NULL)
		{
		temp=[temp next];
		}
	return temp;	
	}
	
- copy
	{
	id new_args=[[COWSArgumentList alloc] init];
	id temp_val=[self last];
	
	while (temp_val!=NULL)
		{
		id new_val=[[COWSStringNode alloc] init];
		[new_val setString:[temp_val string]];
		[new_args push:new_val];
		temp_val=[self prev];
		}
	return new_args;
	}

@end
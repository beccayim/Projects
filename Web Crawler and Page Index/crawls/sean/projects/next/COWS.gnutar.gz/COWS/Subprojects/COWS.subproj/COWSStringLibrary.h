/*
	Copyright (C) 1994 Sean Luke

	COWSStringLibrary.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibrary.h"

@interface COWSStringLibrary:COWSLibrary <InterpreterToLibrary>
{
}

@end
/*
	Copyright (C) 1994 Sean Luke

	COWSNode.m
	Version 1.0
	Sean Luke
	
*/




#import "COWSNode.h"

@implementation COWSNode

- init
	{
	id returnval=[super init];
	next=NULL;
	return returnval;
	}
	
- setNext: this
	{
	next=this;
	return self;
	}
	
- next
	{
	return next;
	}
	
- setPrev: this
	{
	prev=this;
	return self;
	}
	
- prev
	{
	return prev;
	}
	
- free
	{
	return [super free];
	}

@end
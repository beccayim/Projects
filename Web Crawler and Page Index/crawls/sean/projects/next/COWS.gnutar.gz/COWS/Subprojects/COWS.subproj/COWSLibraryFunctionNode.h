/*
	Copyright (C) 1994 Sean Luke

	COWSLibraryFunctionNode.h
	Version 1.0
	Sean Luke
	
*/




#import "COWSLibraryNode.h"

@interface COWSLibraryFunctionNode:COWSLibraryNode
{
	SEL		selector;
}

- setSelector:(SEL) this_selector;
- (SEL) selector;
- printContents;	// debugging...but this does nothing...
	
@end
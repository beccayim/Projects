/*
	Copyright (C) 1994 Sean Luke

	COWSUserController.h
	Version 1.4
	Sean Luke
	
	Allows easy hookup to libraries and control nib and interpreter
	
*/



#import "COWSController.h"
#import <appkit/appkit.h>
#import "COWSProtocols.h"
#define COWSUSERCONTROLLER_MAXERRSTRINGLENGTH	256

@interface COWSUserController:COWSController <InterpreterToDelegate>
{
	id	controlPanel;
}

//	- appDidInit:sender;		// commented out because IB freaks
- load:sender;
- run:sender;
- loadAndRunOrStop:sender;
- setLockedToMe:sender;
- setForegroundToMe:sender;



@end

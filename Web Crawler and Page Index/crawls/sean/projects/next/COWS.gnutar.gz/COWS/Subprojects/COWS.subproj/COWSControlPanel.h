
/*
	Copyright (C) 1994 Sean Luke

	COWSControlPanel.h
	Version 1.4
	Sean Luke
	
	An Easy-To-Hook-Up control panel
	Designed to work with the COWSUserController
	
*/

#import <appkit/appkit.h>

@interface COWSControlPanel:Panel
{
	id	loadAndRunButton;
	id	loadButton;
	id	runButton;
	id	lockedButton;
	id	foregroundButton;
	
	id	function;
	id	arg1;
	id	arg2;
	id	arg3;
	id	arg4;
}

- connect:sender;
- loadAndRunButton;
- loadButton;
- runButton;
- lockedButton;
- foregroundButton;
- function;
- arg1;
- arg2;
- arg3;
- arg4;

@end
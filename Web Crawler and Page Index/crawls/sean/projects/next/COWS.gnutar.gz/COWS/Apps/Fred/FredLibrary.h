/*

Fred
An Obnoxious Little Application
By Sean Luke

Released:  April 1991
Modified for COWS:  March 1994

*/


#import <COWSLibrary.h>
#import <appkit/appkit.h>


@interface FredLibrary:COWSLibrary <InterpreterToLibrary>
{
	id				thisWindow;
	//id				userController;
}

- appDidInit:sender;
- loadLibrary:sender;
- pauseCancelled:sender;			

- fred_iconXPosition:arg_list;
- fred_iconYPosition:arg_list;
- fred_mouseXPosition:arg_list;
- fred_mouseYPosition:arg_list;
- fred_moveIcon:arg_list;

@end

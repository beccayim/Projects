
#import <appkit/appkit.h>
#define MAC_STATUS_STOPPED		0
#define MAC_STATUS_RECORDING	1
#define MAC_STATUS_PLAYING		2


@interface Controller:Object
{
	int status;
	int fd;
	NXJournaler*	journaler;
	NXStream* 		current;
    id	play_button;
    id	record_button;
	id	stop_button;
	id	functionLibrary;
}

- init;
- (int) status;
- play:sender;
- playFile:(const char*) fi;
- record:sender;
- stop:sender;
- journalerDidEnd:this_journaler;
- (BOOL) appAcceptsAnotherFile:sender;
- (int) app:sender openFile:(const char*)filename type:(const char*) aType;

@end

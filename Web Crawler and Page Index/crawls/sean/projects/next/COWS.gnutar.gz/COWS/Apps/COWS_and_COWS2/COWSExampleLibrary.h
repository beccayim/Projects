/*
	Copyright (C) 1994 Sean Luke

	COWSExampleLibrary.h
	Version 1.0
	Sean Luke
	
*/



#import <appkit/appkit.h>
#import "COWSArgumentList.h"
#import "COWSStringNode.h"
#import "COWSLibrary.h"
#import <stdio.h>

@interface COWSExampleLibrary:COWSLibrary <InterpreterToLibrary>

{
	id scroll;
	id check;
	id radio;
	id button;
	id field;
	id window;
}

- loadLibrary:sender;

- scrollValue:arg_list;
- setScrollValue:arg_list;
- checkValue:arg_list;
- setCheckValue:arg_list;
- radioValue:arg_list;
- setRadioValue:arg_list;
- pressButton:arg_list;
- setStringValue:arg_list;
- stringValue:arg_list;
- setWindowPosition:arg_list;
- windowXPosition:arg_list;
- windowYPosition:arg_list;
- windowTitle:arg_list;
- setWindowTitle:arg_list;
- ping:arg_list;


@end
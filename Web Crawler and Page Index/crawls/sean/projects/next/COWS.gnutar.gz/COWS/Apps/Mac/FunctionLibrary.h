/*
	Copyright (C) 1994 Sean Luke

	FunctionLibrary.h
	Version 1.3
	Sean Luke
	
*/




#import <COWSLibrary.h>
#import "Controller.h"

@interface FunctionLibrary:COWSLibrary <InterpreterToLibrary>
{
	BOOL paused;
	id controller;
	id interpreter;
}

- init;
- loadLibrary:sender;
- pauseCancelled:sender;
- function_play:arg_list;

@end
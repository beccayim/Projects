/*
	Copyright (C) 1994 Sean Luke

	COWSMiscCategories.m
	Version 1.0
	Sean Luke
	
*/

#import "COWSMiscCategories.h"


@implementation COWSObjectLibrary (COWSObjectLibraryIB)

- (NXImage*) getIBImage
	{
	return [NXImage findImageNamed:"COWSLibrary"];
	}


@end

@implementation COWSExtendedMathLibrary (COWSExtendedMathLibraryIB)
- (NXImage*) getIBImage
	{
	return [NXImage findImageNamed:"COWSLibrary"];
	}
@end




#import "COWS_MiscPalette.h"


@implementation  COWS_MiscPalette

- finishInstantiate 
	{
	[self associateObject:extendedMathLibrary
		type:IBWindowPboardType with:extendedMathButton];
	[self associateObject:objectLibrary
		type:IBWindowPboardType with:objectButton];
   	return self;
	}

@end

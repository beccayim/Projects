/*
	Copyright (C) 1994 Sean Luke

	COWSUserControllerInspector.h
	Version 1.4
	Sean Luke
	
	Only used in the COWS Palette to provide inspection for the COWSController
	and COWSUserController.
	
*/



#import "COWSControllerInspector.h"

@interface COWSUserControllerInspector:COWSControllerInspector <IBInspectors>
{
}

- init;
@end
#import <apps/InterfaceBuilder.h>

@interface COWS_MiscPalette:IBPalette 
{
	id	extendedMathButton;
	id	extendedMathLibrary;
	id	objectButton;
	id	objectLibrary;
}

@end

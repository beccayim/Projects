/*
	Copyright (C) 1994 Sean Luke

	COWSIBControlInterfaceInspector.h
	Version 1.4
	Sean Luke
	
	Only used in the COWS IB Connectors palette to inspect 
	COWSIBControlInterfaces	
	
*/



#import <apps/InterfaceBuilder.h>

@interface COWSIBControlInterfaceInspector:IBInspector <IBInspectors>
{
	id	fieldmatrix;
	id	defaultinputfield;
	id	outputfield;
	id 	use_radio;

}

- init;

@end
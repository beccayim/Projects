/*
	Copyright (C) 1994 Sean Luke

	COWSMiscCategories.h
	Version 1.0
	Sean Luke
	
*/

#import "COWSObjectLibrary.h"
#import "COWSExtendedMathLibrary.h"

@interface COWSObjectLibrary (COWSObjectLibraryIB)
- (NXImage*) getIBImage;
@end

@interface COWSExtendedMathLibrary (COWSExtendedMathLibraryIB)
- (NXImage*) getIBImage;
@end

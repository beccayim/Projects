/*
	Copyright (C) 1994 Sean Luke

	COWSControllerInspector.h
	Version 1.4
	Sean Luke
	
	Only used in the COWS Palette to provide inspection for the COWSController
	and COWSUserController.
	
*/



#import <apps/InterfaceBuilder.h>

@interface COWSControllerInspector:IBInspector <IBInspectors>
{
	id	fieldmatrix;
	id	buttonmatrix;
	id	automatrix;
}

- init;
- okSuper:sender;		// sent by subclasses when they want to send
						// okay:sender to IBInspector, bypassing this
						// class
- revertSuper:sender;	// likewise
@end


#import "COWS_IBConnectors.h"


@implementation  COWS_IBConnectors

- finishInstantiate 
{
    [self associateObject:IBSplitter 
        type:IBObjectPboardType with:IBSplitterButton];
    [self associateObject:IBRadio 
        type:IBObjectPboardType with:IBRadioButton];
    [self associateObject:IBControlInterface 
        type:IBObjectPboardType with:IBControlInterfaceButton];
   return self;
}

@end

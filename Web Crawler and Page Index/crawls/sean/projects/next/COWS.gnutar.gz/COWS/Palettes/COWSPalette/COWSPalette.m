

#import "COWSPalette.h"


@implementation  COWSPalette

- finishInstantiate 
{
    [self associateObject:userController 
        type:IBObjectPboardType with:userControllerButton];
    [self associateObject:controller 
        type:IBObjectPboardType with:controllerButton];
    [self associateObject:interpreter 
        type:IBObjectPboardType with:interpreterButton];
    [self associateObject:controlPanel 
        type:IBWindowPboardType with:controlPanelButton];
    [self associateObject:standardLibrary 
        type:IBWindowPboardType with:standardLibraryButton];
    [self associateObject:arrayLibrary 
        type:IBWindowPboardType with:arrayLibraryButton];
    [self associateObject:ipcLibrary 
        type:IBWindowPboardType with:ipcLibraryButton];
	[self associateObject:systemLibrary
		type:IBWindowPboardType with:systemLibraryButton];
	[self associateObject:mathLibrary
		type:IBWindowPboardType with:mathLibraryButton];
	[self associateObject:stringLibrary
		type:IBWindowPboardType with:stringLibraryButton];
   return self;
}

@end

#import <apps/InterfaceBuilder.h>

@interface COWSPalette:IBPalette 
{
	id	userController;
	id	controller;
	id	interpreter;
	id	controlPanel;
	id	standardLibrary;
	id	arrayLibrary;
	id	ipcLibrary;
	id	systemLibrary;
	id	mathLibrary;
	id	stringLibrary;
	
	id	userControllerButton;
	id	controllerButton;
	id	interpreterButton;
	id	controlPanelButton;
	id	standardLibraryButton;
	id	arrayLibraryButton;
	id	ipcLibraryButton;
	id	systemLibraryButton;
	id	mathLibraryButton;
	id	stringLibraryButton;
}

- finishInstantiate;

@end

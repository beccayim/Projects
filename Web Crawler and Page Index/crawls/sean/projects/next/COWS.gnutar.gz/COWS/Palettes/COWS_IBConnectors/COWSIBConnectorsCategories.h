/*
	Copyright (C) 1994 Sean Luke

	COWSIBConnectorsCategories.h
	Version 1.0
	Sean Luke
	
*/

#import "COWSIBControlInterface.h"
#import "COWSIBRadio.h"
#import "COWSIBSplitter.h"


@interface COWSIBControlInterface (COWSIBControlInterfaceIB)


- setOutputValue:(const char*)this;
- setDefaultInputValue:(const char*)this;
- setInput1Value:(const char*)this;
- setInput2Value:(const char*)this;
- setInput3Value:(const char*)this;
- setInput4Value:(const char*)this;
- setInput5Value:(const char*)this;
- setInput6Value:(const char*)this;
- setInput7Value:(const char*)this;
- setInput8Value:(const char*)this;

- (const char*) outputValue;
- (const char*) defaultInputValue;
- (const char*) input1Value;
- (const char*) input2Value;
- (const char*) input3Value;
- (const char*) input4Value;
- (const char*) input5Value;
- (const char*) input6Value;
- (const char*) input7Value;
- (const char*) input8Value;

- (BOOL) usingRadio;
- useRadio:(BOOL) yes_or_no;
- (const char*)getInspectorClassName;
- (NXImage*) getIBImage;
@end

@interface COWSIBRadio (COWSIBRadioIB)
- (NXImage*) getIBImage;
@end

@interface COWSIBSplitter (COWSIBSplitterIB)
- (BOOL) usingRadio;
- useRadio:(BOOL) yes_or_no;
- (const char*)getInspectorClassName;
- (NXImage*) getIBImage;
@end
#import <apps/InterfaceBuilder.h>

@interface COWS_IBConnectors:IBPalette 
{
	id	IBSplitter;
	id	IBRadio;
	id	IBControlInterface;
	
	id	IBSplitterButton;
	id	IBRadioButton;
	id	IBControlInterfaceButton;
}

- finishInstantiate;

@end
